from django.db import models
from django.urls import reverse
from django.shortcuts import get_object_or_404, render

class Product(models.Model):
    name = models.CharField(max_length=200)
    price = models.PositiveIntegerField()

    def __str__(self):
        return self.name

    # 新規作成・編集完了時のリダイレクト先
    def get_absolute_url(self):
        return reverse('list')

# ここからはビュー関数 (クラス外に定義)
def product_detail_view(request, pk):
    product = get_object_or_404(Product, pk=pk)
    return render(request, 'crud/product_detail.html', {'product': product})


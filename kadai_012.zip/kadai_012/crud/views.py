from django.views.generic import TemplateView, ListView
from django.views.generic.edit import CreateView, UpdateView, DeleteView
from django.views.generic import DetailView
from .models import Product
from django.urls import reverse_lazy
from django.shortcuts import render, get_object_or_404
from django.views.generic import DetailView


class TopView(TemplateView):
     template_name = "top.html"

class ProductListView(ListView):
    model = Product
    paginate_by = 3
    
class ProductCreateView(CreateView):
    model = Product
    fields = ['name', 'price', 'category', 'description', 'image']
    
class ProductUpdateView(UpdateView):
    model = Product
    fields = ['name', 'price', 'category', 'description', 'image']  # 同様に、更新時に使いたいフィールドを指定
    template_name_suffix = '_update_form'
    
class ProductDeleteView(DeleteView):
    model = Product
    success_url = reverse_lazy('list')  
    
class ProductDetailView(DetailView):
    model = Product
    template_name = 'crud/product_detail.html'
    context_object_name = 'product'